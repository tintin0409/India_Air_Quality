# Your name: <Enter Tin Nguyen>
## Assignment Name: CA01 - Data Cleaning and Exploration of India Air Quality

# Program Inititialization Section
## Enter your import packages here


```python
# import packages 
import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
import matplotlib.pyplot as plt
```

# Data File Reading Section
## Write code to read in data from external sources here


```python
# Initial Data Investigation Section

## Summarized details
### Generate descriptive statistics that summarize the central tendency, dispersion, and shape of a dataset’s distribution, excluding NaN values.
#### Steps:
#### 1. Statistical Description of data (data.describe)
#### 2. Display number of total rows and columns of the dataset (data.shape)
#### 3. Display number of non-null values for each column (data.count)
#### 4. Display number of null values for each column (sum of data.isnull)
#### 5. Display range, column, number of non-null objects of each column, datatype and memory usage (data.info)
#### 6. Display Top 10 and Bottom 10 records (head and tail)
```


```python
#read datasets
df= pd.read_csv('data.csv', engine='python', na_values = 'NaN')

df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>stn_code</th>
      <th>sampling_date</th>
      <th>state</th>
      <th>location</th>
      <th>agency</th>
      <th>type</th>
      <th>so2</th>
      <th>no2</th>
      <th>rspm</th>
      <th>spm</th>
      <th>location_monitoring_station</th>
      <th>pm2_5</th>
      <th>date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>150</td>
      <td>February - M021990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Residential, Rural and other Areas</td>
      <td>4.8</td>
      <td>17.4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-02-01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>151</td>
      <td>February - M021990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Industrial Area</td>
      <td>3.1</td>
      <td>7.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-02-01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>152</td>
      <td>February - M021990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Residential, Rural and other Areas</td>
      <td>6.2</td>
      <td>28.5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-02-01</td>
    </tr>
    <tr>
      <th>3</th>
      <td>150</td>
      <td>March - M031990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Residential, Rural and other Areas</td>
      <td>6.3</td>
      <td>14.7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-03-01</td>
    </tr>
    <tr>
      <th>4</th>
      <td>151</td>
      <td>March - M031990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Industrial Area</td>
      <td>4.7</td>
      <td>7.5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-03-01</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Your code for this section here ...
#1.Statistical Description of data (data.describe)
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>so2</th>
      <th>no2</th>
      <th>rspm</th>
      <th>spm</th>
      <th>pm2_5</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>401096.000000</td>
      <td>419509.000000</td>
      <td>395520.000000</td>
      <td>198355.000000</td>
      <td>9314.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>10.829414</td>
      <td>25.809623</td>
      <td>108.832784</td>
      <td>220.783480</td>
      <td>40.791467</td>
    </tr>
    <tr>
      <th>std</th>
      <td>11.177187</td>
      <td>18.503086</td>
      <td>74.872430</td>
      <td>151.395457</td>
      <td>30.832525</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>5.000000</td>
      <td>14.000000</td>
      <td>56.000000</td>
      <td>111.000000</td>
      <td>24.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>8.000000</td>
      <td>22.000000</td>
      <td>90.000000</td>
      <td>187.000000</td>
      <td>32.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>13.700000</td>
      <td>32.200000</td>
      <td>142.000000</td>
      <td>296.000000</td>
      <td>46.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>909.000000</td>
      <td>876.000000</td>
      <td>6307.033333</td>
      <td>3380.000000</td>
      <td>504.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#2. Display number of total rows and columns of the dataset (data.shape)
df.shape
```




    (435742, 13)




```python
#3. Display number of non-null values for each column (data.count)
df.count()
```




    stn_code                       291665
    sampling_date                  435739
    state                          435742
    location                       435739
    agency                         286261
    type                           430349
    so2                            401096
    no2                            419509
    rspm                           395520
    spm                            198355
    location_monitoring_station    408251
    pm2_5                            9314
    date                           435735
    dtype: int64




```python
#4. Display number of null values for each column (sum of data.isnull)
df.isnull().sum()
```




    stn_code                       144077
    sampling_date                       3
    state                               0
    location                            3
    agency                         149481
    type                             5393
    so2                             34646
    no2                             16233
    rspm                            40222
    spm                            237387
    location_monitoring_station     27491
    pm2_5                          426428
    date                                7
    dtype: int64




```python
#5. Display range, column, number of non-null objects of each column, datatype and memory usage (data.info)
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 435742 entries, 0 to 435741
    Data columns (total 13 columns):
     #   Column                       Non-Null Count   Dtype  
    ---  ------                       --------------   -----  
     0   stn_code                     291665 non-null  object 
     1   sampling_date                435739 non-null  object 
     2   state                        435742 non-null  object 
     3   location                     435739 non-null  object 
     4   agency                       286261 non-null  object 
     5   type                         430349 non-null  object 
     6   so2                          401096 non-null  float64
     7   no2                          419509 non-null  float64
     8   rspm                         395520 non-null  float64
     9   spm                          198355 non-null  float64
     10  location_monitoring_station  408251 non-null  object 
     11  pm2_5                        9314 non-null    float64
     12  date                         435735 non-null  object 
    dtypes: float64(5), object(8)
    memory usage: 43.2+ MB
    


```python
#6. Display Top 10 and Bottom 10 records (head and tail)
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>stn_code</th>
      <th>sampling_date</th>
      <th>state</th>
      <th>location</th>
      <th>agency</th>
      <th>type</th>
      <th>so2</th>
      <th>no2</th>
      <th>rspm</th>
      <th>spm</th>
      <th>location_monitoring_station</th>
      <th>pm2_5</th>
      <th>date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>150</td>
      <td>February - M021990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Residential, Rural and other Areas</td>
      <td>4.8</td>
      <td>17.4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-02-01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>151</td>
      <td>February - M021990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Industrial Area</td>
      <td>3.1</td>
      <td>7.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-02-01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>152</td>
      <td>February - M021990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Residential, Rural and other Areas</td>
      <td>6.2</td>
      <td>28.5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-02-01</td>
    </tr>
    <tr>
      <th>3</th>
      <td>150</td>
      <td>March - M031990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Residential, Rural and other Areas</td>
      <td>6.3</td>
      <td>14.7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-03-01</td>
    </tr>
    <tr>
      <th>4</th>
      <td>151</td>
      <td>March - M031990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Industrial Area</td>
      <td>4.7</td>
      <td>7.5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-03-01</td>
    </tr>
    <tr>
      <th>5</th>
      <td>152</td>
      <td>March - M031990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Residential, Rural and other Areas</td>
      <td>6.4</td>
      <td>25.7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-03-01</td>
    </tr>
    <tr>
      <th>6</th>
      <td>150</td>
      <td>April - M041990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Residential, Rural and other Areas</td>
      <td>5.4</td>
      <td>17.1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-04-01</td>
    </tr>
    <tr>
      <th>7</th>
      <td>151</td>
      <td>April - M041990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Industrial Area</td>
      <td>4.7</td>
      <td>8.7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-04-01</td>
    </tr>
    <tr>
      <th>8</th>
      <td>152</td>
      <td>April - M041990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Residential, Rural and other Areas</td>
      <td>4.2</td>
      <td>23.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-04-01</td>
    </tr>
    <tr>
      <th>9</th>
      <td>151</td>
      <td>May - M051990</td>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>NaN</td>
      <td>Industrial Area</td>
      <td>4.0</td>
      <td>8.9</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-05-01</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>stn_code</th>
      <th>sampling_date</th>
      <th>state</th>
      <th>location</th>
      <th>agency</th>
      <th>type</th>
      <th>so2</th>
      <th>no2</th>
      <th>rspm</th>
      <th>spm</th>
      <th>location_monitoring_station</th>
      <th>pm2_5</th>
      <th>date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>435732</th>
      <td>SAMP</td>
      <td>09-12-15</td>
      <td>West Bengal</td>
      <td>ULUBERIA</td>
      <td>West Bengal State Pollution Control Board</td>
      <td>RIRUO</td>
      <td>22.0</td>
      <td>50.0</td>
      <td>145.0</td>
      <td>NaN</td>
      <td>Inside Rampal Industries,ULUBERIA</td>
      <td>NaN</td>
      <td>2015-12-09</td>
    </tr>
    <tr>
      <th>435733</th>
      <td>SAMP</td>
      <td>12-12-15</td>
      <td>West Bengal</td>
      <td>ULUBERIA</td>
      <td>West Bengal State Pollution Control Board</td>
      <td>RIRUO</td>
      <td>34.0</td>
      <td>61.0</td>
      <td>161.0</td>
      <td>NaN</td>
      <td>Inside Rampal Industries,ULUBERIA</td>
      <td>NaN</td>
      <td>2015-12-12</td>
    </tr>
    <tr>
      <th>435734</th>
      <td>SAMP</td>
      <td>15-12-15</td>
      <td>West Bengal</td>
      <td>ULUBERIA</td>
      <td>West Bengal State Pollution Control Board</td>
      <td>RIRUO</td>
      <td>20.0</td>
      <td>44.0</td>
      <td>148.0</td>
      <td>NaN</td>
      <td>Inside Rampal Industries,ULUBERIA</td>
      <td>NaN</td>
      <td>2015-12-15</td>
    </tr>
    <tr>
      <th>435735</th>
      <td>SAMP</td>
      <td>18-12-15</td>
      <td>West Bengal</td>
      <td>ULUBERIA</td>
      <td>West Bengal State Pollution Control Board</td>
      <td>RIRUO</td>
      <td>17.0</td>
      <td>44.0</td>
      <td>131.0</td>
      <td>NaN</td>
      <td>Inside Rampal Industries,ULUBERIA</td>
      <td>NaN</td>
      <td>2015-12-18</td>
    </tr>
    <tr>
      <th>435736</th>
      <td>SAMP</td>
      <td>21-12-15</td>
      <td>West Bengal</td>
      <td>ULUBERIA</td>
      <td>West Bengal State Pollution Control Board</td>
      <td>RIRUO</td>
      <td>18.0</td>
      <td>45.0</td>
      <td>140.0</td>
      <td>NaN</td>
      <td>Inside Rampal Industries,ULUBERIA</td>
      <td>NaN</td>
      <td>2015-12-21</td>
    </tr>
    <tr>
      <th>435737</th>
      <td>SAMP</td>
      <td>24-12-15</td>
      <td>West Bengal</td>
      <td>ULUBERIA</td>
      <td>West Bengal State Pollution Control Board</td>
      <td>RIRUO</td>
      <td>22.0</td>
      <td>50.0</td>
      <td>143.0</td>
      <td>NaN</td>
      <td>Inside Rampal Industries,ULUBERIA</td>
      <td>NaN</td>
      <td>2015-12-24</td>
    </tr>
    <tr>
      <th>435738</th>
      <td>SAMP</td>
      <td>29-12-15</td>
      <td>West Bengal</td>
      <td>ULUBERIA</td>
      <td>West Bengal State Pollution Control Board</td>
      <td>RIRUO</td>
      <td>20.0</td>
      <td>46.0</td>
      <td>171.0</td>
      <td>NaN</td>
      <td>Inside Rampal Industries,ULUBERIA</td>
      <td>NaN</td>
      <td>2015-12-29</td>
    </tr>
    <tr>
      <th>435739</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>andaman-and-nicobar-islands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>435740</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>Lakshadweep</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>435741</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>Tripura</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



## Cleansing the dataset
### Dropping of less valued columns:
1. stn_code, agency, sampling_date, location_monitoring_agency do not add much value to the dataset in terms of information. Therefore, we can drop those columns.

2. Dropping rows where no date is available.


```python
# Cleaning up the data

#dropping columns that aren't required

df.drop(columns=['stn_code', 'agency', 'sampling_date', 'location_monitoring_station'], inplace=True)

```


```python
# dropping rows where no date is available

df = df[df['date'].notna()]


```


```python
df.date
```




    0         1990-02-01
    1         1990-02-01
    2         1990-02-01
    3         1990-03-01
    4         1990-03-01
                 ...    
    435734    2015-12-15
    435735    2015-12-18
    435736    2015-12-21
    435737    2015-12-24
    435738    2015-12-29
    Name: date, Length: 435735, dtype: object




```python
# displaying final columns (data.columns)

df.columns
```




    Index(['state', 'location', 'type', 'so2', 'no2', 'rspm', 'spm', 'pm2_5',
           'date'],
          dtype='object')



### Changing the types to uniform format:

Notice that the ‘type’ column has values such as ‘Industrial Area’ and ‘Industrial Areas’ — both actually mean the same, so let’s remove such type of stuff and make it uniform. Replace the 'type' values with standard codes as follows:

types = {
    "Residential": "R",
    "Residential and others": "RO",
    "Residential, Rural and other Areas": "RRO",
    "Industrial Area": "I",
    "Industrial Areas": "I",
    "Industrial": "I",
    "Sensitive Area": "S",
    "Sensitive Areas": "S",
    "Sensitive": "S",
    np.nan: "RRO"
}

data.type = data.type.replace(types)


```python
# ... Your code here
df.type = df.type.replace({"Residential": "R", "Residential and others": "RO", "Residential, Rural and other Areas": "RRO", "Industrial Area": "I", "Industrial Areas": "I", "Industrial": "I", "Sensitive Area": "S", "Sensitive Areas": "S", "Sensitive": "S", np.nan: "RRO"})

```


```python
# Display top 10 records after codification of 'types'
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state</th>
      <th>location</th>
      <th>type</th>
      <th>so2</th>
      <th>no2</th>
      <th>rspm</th>
      <th>spm</th>
      <th>pm2_5</th>
      <th>date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>RRO</td>
      <td>4.8</td>
      <td>17.4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-02-01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>I</td>
      <td>3.1</td>
      <td>7.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-02-01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>RRO</td>
      <td>6.2</td>
      <td>28.5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-02-01</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>RRO</td>
      <td>6.3</td>
      <td>14.7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-03-01</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>I</td>
      <td>4.7</td>
      <td>7.5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-03-01</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>RRO</td>
      <td>6.4</td>
      <td>25.7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-03-01</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>RRO</td>
      <td>5.4</td>
      <td>17.1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-04-01</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>I</td>
      <td>4.7</td>
      <td>8.7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-04-01</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>RRO</td>
      <td>4.2</td>
      <td>23.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-04-01</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Andhra Pradesh</td>
      <td>Hyderabad</td>
      <td>I</td>
      <td>4.0</td>
      <td>8.9</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1990-05-01</td>
    </tr>
  </tbody>
</table>
</div>



### Creating a year column
To view the trend over a period of time, we need year values for each row and also when you see in most of the values in date column only has ‘year’ value. So, let’s create a new column holding year values. Convert the column to 'datetime' type and extract the year to populate the new column. Display Top 5 records after the conversion.


```python
# ... Your code here
df['year'] = pd.DatetimeIndex(df['date']).year
```


```python
year_top_5_values = df.groupby(['year']).agg({'date':'count'}).sort_values(by='date', ascending=False).head(5)
```


```python
year_top_5_values
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
    </tr>
    <tr>
      <th>year</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015</th>
      <td>50319</td>
    </tr>
    <tr>
      <th>2013</th>
      <td>45803</td>
    </tr>
    <tr>
      <th>2014</th>
      <td>44215</td>
    </tr>
    <tr>
      <th>2011</th>
      <td>37641</td>
    </tr>
    <tr>
      <th>2012</th>
      <td>35101</td>
    </tr>
  </tbody>
</table>
</div>



### Handling Missing Values

The column such as SO2, NO2, rspm, spm, pm2_5 are the ones which contribute much to our analysis. So, we need to remove null from those columns to avoid inaccuracy in the prediction.
We use the Imputer from sklearn.preprocessing to fill the missing values in every column with the mean.


```python
# define columns of importance, which shall be used reguarly (COLS = ....)
# invoke SimpleImputer to fill missing values using 'mean' as the replacement strategy



imp = SimpleImputer(missing_values=np.nan, strategy='mean')
df.so2= imp.fit_transform(df['so2'].values.reshape(-1,1))[:,0]
df.no2= imp.fit_transform(df['no2'].values.reshape(-1,1))[:,0]
df.rspm= imp.fit_transform(df['rspm'].values.reshape(-1,1))[:,0]
df.spm= imp.fit_transform(df['spm'].values.reshape(-1,1))[:,0]
df.pm2_5= imp.fit_transform(df['pm2_5'].values.reshape(-1,1))[:,0]
```


```python
# Display data.info after the transformation
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 435735 entries, 0 to 435738
    Data columns (total 10 columns):
     #   Column    Non-Null Count   Dtype  
    ---  ------    --------------   -----  
     0   state     435735 non-null  object 
     1   location  435735 non-null  object 
     2   type      435735 non-null  object 
     3   so2       435735 non-null  float64
     4   no2       435735 non-null  float64
     5   rspm      435735 non-null  float64
     6   spm       435735 non-null  float64
     7   pm2_5     435735 non-null  float64
     8   date      435735 non-null  object 
     9   year      435735 non-null  int64  
    dtypes: float64(5), int64(1), object(4)
    memory usage: 56.6+ MB
    


```python
# Display that there are no more missing values in the dataset
df.isnull().sum()
```




    state       0
    location    0
    type        0
    so2         0
    no2         0
    rspm        0
    spm         0
    pm2_5       0
    date        0
    year        0
    dtype: int64



## Statewise Grouping of so2, no2, rspm, spm values

Calculate median values of so2, no2, rspm, spm for each state and display in (a) as table (b) bar chart, with values sorted in ascending order. Separate section for each of the component. Use matplotlib().

### so2 status


```python
#a
so2_status = df.groupby(['state']).agg({'so2':'median'}).sort_values(by='so2', ascending=True)
so2_status
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>so2</th>
    </tr>
    <tr>
      <th>state</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Nagaland</th>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>Mizoram</th>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>Meghalaya</th>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>Arunachal Pradesh</th>
      <td>2.500000</td>
    </tr>
    <tr>
      <th>Himachal Pradesh</th>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>Kerala</th>
      <td>4.200000</td>
    </tr>
    <tr>
      <th>Telangana</th>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>Odisha</th>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>Jammu &amp; Kashmir</th>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>Andhra Pradesh</th>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>Goa</th>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>Rajasthan</th>
      <td>6.300000</td>
    </tr>
    <tr>
      <th>Delhi</th>
      <td>6.300000</td>
    </tr>
    <tr>
      <th>Assam</th>
      <td>6.500000</td>
    </tr>
    <tr>
      <th>Puducherry</th>
      <td>7.266667</td>
    </tr>
    <tr>
      <th>Daman &amp; Diu</th>
      <td>7.600000</td>
    </tr>
    <tr>
      <th>Chandigarh</th>
      <td>7.950000</td>
    </tr>
    <tr>
      <th>West Bengal</th>
      <td>8.000000</td>
    </tr>
    <tr>
      <th>Dadra &amp; Nagar Haveli</th>
      <td>8.400000</td>
    </tr>
    <tr>
      <th>Karnataka</th>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>Uttar Pradesh</th>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>Tamil Nadu</th>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>Punjab</th>
      <td>10.300000</td>
    </tr>
    <tr>
      <th>Manipur</th>
      <td>10.829428</td>
    </tr>
    <tr>
      <th>Bihar</th>
      <td>10.829428</td>
    </tr>
    <tr>
      <th>Haryana</th>
      <td>10.829428</td>
    </tr>
    <tr>
      <th>Madhya Pradesh</th>
      <td>10.829428</td>
    </tr>
    <tr>
      <th>Chhattisgarh</th>
      <td>12.500000</td>
    </tr>
    <tr>
      <th>Maharashtra</th>
      <td>13.000000</td>
    </tr>
    <tr>
      <th>Gujarat</th>
      <td>14.200000</td>
    </tr>
    <tr>
      <th>Jharkhand</th>
      <td>18.700000</td>
    </tr>
    <tr>
      <th>Sikkim</th>
      <td>19.800000</td>
    </tr>
    <tr>
      <th>Uttarakhand</th>
      <td>21.000000</td>
    </tr>
    <tr>
      <th>Uttaranchal</th>
      <td>25.100000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#b
plt.bar(so2_status.index,so2_status.so2, color='blue')
plt.title('Bar Plot')
plt.xlabel('state')
plt.ylabel('median_so2')
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_32_0.png)
    


### no2 status


```python
#a
no2_status = df.groupby(['state']).agg({'no2':'median'}).sort_values(by='no2', ascending=True)
no2_status
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>no2</th>
    </tr>
    <tr>
      <th>state</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Arunachal Pradesh</th>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>Mizoram</th>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>Nagaland</th>
      <td>7.000000</td>
    </tr>
    <tr>
      <th>Meghalaya</th>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>Goa</th>
      <td>11.600000</td>
    </tr>
    <tr>
      <th>Puducherry</th>
      <td>13.000000</td>
    </tr>
    <tr>
      <th>Jammu &amp; Kashmir</th>
      <td>13.000000</td>
    </tr>
    <tr>
      <th>Himachal Pradesh</th>
      <td>13.900000</td>
    </tr>
    <tr>
      <th>Kerala</th>
      <td>14.000000</td>
    </tr>
    <tr>
      <th>Assam</th>
      <td>14.000000</td>
    </tr>
    <tr>
      <th>Odisha</th>
      <td>16.000000</td>
    </tr>
    <tr>
      <th>Daman &amp; Diu</th>
      <td>17.600000</td>
    </tr>
    <tr>
      <th>Chandigarh</th>
      <td>18.000000</td>
    </tr>
    <tr>
      <th>Dadra &amp; Nagar Haveli</th>
      <td>18.000000</td>
    </tr>
    <tr>
      <th>Madhya Pradesh</th>
      <td>19.200000</td>
    </tr>
    <tr>
      <th>Manipur</th>
      <td>19.800000</td>
    </tr>
    <tr>
      <th>Andhra Pradesh</th>
      <td>20.000000</td>
    </tr>
    <tr>
      <th>Tamil Nadu</th>
      <td>21.000000</td>
    </tr>
    <tr>
      <th>Karnataka</th>
      <td>21.200000</td>
    </tr>
    <tr>
      <th>Chhattisgarh</th>
      <td>21.500000</td>
    </tr>
    <tr>
      <th>Telangana</th>
      <td>22.000000</td>
    </tr>
    <tr>
      <th>Haryana</th>
      <td>22.750000</td>
    </tr>
    <tr>
      <th>Gujarat</th>
      <td>23.000000</td>
    </tr>
    <tr>
      <th>Uttarakhand</th>
      <td>25.809659</td>
    </tr>
    <tr>
      <th>Rajasthan</th>
      <td>26.000000</td>
    </tr>
    <tr>
      <th>Sikkim</th>
      <td>26.800000</td>
    </tr>
    <tr>
      <th>Uttar Pradesh</th>
      <td>27.000000</td>
    </tr>
    <tr>
      <th>Uttaranchal</th>
      <td>27.500000</td>
    </tr>
    <tr>
      <th>Punjab</th>
      <td>28.300000</td>
    </tr>
    <tr>
      <th>Maharashtra</th>
      <td>29.000000</td>
    </tr>
    <tr>
      <th>Bihar</th>
      <td>32.000000</td>
    </tr>
    <tr>
      <th>Jharkhand</th>
      <td>42.000000</td>
    </tr>
    <tr>
      <th>Delhi</th>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>West Bengal</th>
      <td>53.700000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#b
plt.bar(no2_status.index,no2_status.no2, color='red')
plt.title('Bar Plot')
plt.xlabel('state')
plt.ylabel('median_no2')
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_35_0.png)
    


### rspm status


```python
#a
rspm_status = df.groupby(['state']).agg({'rspm':'median'}).sort_values(by='rspm', ascending=True)
rspm_status
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rspm</th>
    </tr>
    <tr>
      <th>state</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Sikkim</th>
      <td>32.000000</td>
    </tr>
    <tr>
      <th>Mizoram</th>
      <td>40.000000</td>
    </tr>
    <tr>
      <th>Puducherry</th>
      <td>46.000000</td>
    </tr>
    <tr>
      <th>Kerala</th>
      <td>49.000000</td>
    </tr>
    <tr>
      <th>Goa</th>
      <td>56.000000</td>
    </tr>
    <tr>
      <th>Meghalaya</th>
      <td>57.000000</td>
    </tr>
    <tr>
      <th>Tamil Nadu</th>
      <td>59.000000</td>
    </tr>
    <tr>
      <th>Manipur</th>
      <td>61.000000</td>
    </tr>
    <tr>
      <th>Karnataka</th>
      <td>63.000000</td>
    </tr>
    <tr>
      <th>Arunachal Pradesh</th>
      <td>74.500000</td>
    </tr>
    <tr>
      <th>Andhra Pradesh</th>
      <td>76.000000</td>
    </tr>
    <tr>
      <th>Assam</th>
      <td>77.000000</td>
    </tr>
    <tr>
      <th>Nagaland</th>
      <td>78.000000</td>
    </tr>
    <tr>
      <th>Telangana</th>
      <td>80.000000</td>
    </tr>
    <tr>
      <th>Odisha</th>
      <td>81.000000</td>
    </tr>
    <tr>
      <th>Himachal Pradesh</th>
      <td>90.000000</td>
    </tr>
    <tr>
      <th>Chandigarh</th>
      <td>90.000000</td>
    </tr>
    <tr>
      <th>Dadra &amp; Nagar Haveli</th>
      <td>91.000000</td>
    </tr>
    <tr>
      <th>Gujarat</th>
      <td>95.000000</td>
    </tr>
    <tr>
      <th>West Bengal</th>
      <td>96.000000</td>
    </tr>
    <tr>
      <th>Maharashtra</th>
      <td>96.000000</td>
    </tr>
    <tr>
      <th>Chhattisgarh</th>
      <td>108.833091</td>
    </tr>
    <tr>
      <th>Madhya Pradesh</th>
      <td>108.833091</td>
    </tr>
    <tr>
      <th>Bihar</th>
      <td>108.833091</td>
    </tr>
    <tr>
      <th>Daman &amp; Diu</th>
      <td>108.833091</td>
    </tr>
    <tr>
      <th>Uttaranchal</th>
      <td>112.000000</td>
    </tr>
    <tr>
      <th>Rajasthan</th>
      <td>112.000000</td>
    </tr>
    <tr>
      <th>Jammu &amp; Kashmir</th>
      <td>116.000000</td>
    </tr>
    <tr>
      <th>Uttarakhand</th>
      <td>135.000000</td>
    </tr>
    <tr>
      <th>Delhi</th>
      <td>136.000000</td>
    </tr>
    <tr>
      <th>Haryana</th>
      <td>137.500000</td>
    </tr>
    <tr>
      <th>Punjab</th>
      <td>147.000000</td>
    </tr>
    <tr>
      <th>Uttar Pradesh</th>
      <td>160.000000</td>
    </tr>
    <tr>
      <th>Jharkhand</th>
      <td>165.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#b
plt.bar(rspm_status.index,rspm_status.rspm, color='yellow')
plt.title('Bar Plot')
plt.xlabel('state')
plt.ylabel('median_rspm')
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_38_0.png)
    


### spm status


```python
#a
spm_status = df.groupby(['state']).agg({'spm':'median'}).sort_values(by='spm', ascending=True)
spm_status
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>spm</th>
    </tr>
    <tr>
      <th>state</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Sikkim</th>
      <td>75.00000</td>
    </tr>
    <tr>
      <th>Manipur</th>
      <td>120.50000</td>
    </tr>
    <tr>
      <th>Puducherry</th>
      <td>191.00000</td>
    </tr>
    <tr>
      <th>Goa</th>
      <td>199.00000</td>
    </tr>
    <tr>
      <th>Daman &amp; Diu</th>
      <td>200.50000</td>
    </tr>
    <tr>
      <th>Andhra Pradesh</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Meghalaya</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Mizoram</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Nagaland</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Odisha</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Punjab</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Tamil Nadu</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Telangana</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Uttar Pradesh</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Uttarakhand</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Rajasthan</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Maharashtra</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Kerala</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Karnataka</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Jharkhand</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Jammu &amp; Kashmir</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Himachal Pradesh</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Haryana</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Gujarat</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Dadra &amp; Nagar Haveli</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Chhattisgarh</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Chandigarh</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Bihar</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Assam</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Arunachal Pradesh</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Madhya Pradesh</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>West Bengal</th>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>Delhi</th>
      <td>253.00000</td>
    </tr>
    <tr>
      <th>Uttaranchal</th>
      <td>268.00000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#b
plt.bar(spm_status.index,spm_status.spm, color='purple')
plt.title('Bar Plot')
plt.xlabel('state')
plt.ylabel('median_spm')
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_41_0.png)
    


### What is the yearly trend in a particular state, say ‘Andhra Pradesh’?

Create a new dataframe containing the NO2, SO2, rspm, and spm data regarding state ‘Andhra Pradesh’ only and group it by ‘year’. Display top 5 records after.


```python
AndhraPradesh_records = df[df.state == 'Andhra Pradesh'].groupby(['year']).agg({'no2':'median','so2':'median','rspm':'median','spm':'median'})
```


```python
AndhraPradesh_records.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>no2</th>
      <th>so2</th>
      <th>rspm</th>
      <th>spm</th>
    </tr>
    <tr>
      <th>year</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1990</th>
      <td>13.6</td>
      <td>5.60</td>
      <td>108.833091</td>
      <td>179.00000</td>
    </tr>
    <tr>
      <th>1991</th>
      <td>12.8</td>
      <td>8.25</td>
      <td>108.833091</td>
      <td>141.50000</td>
    </tr>
    <tr>
      <th>1992</th>
      <td>27.6</td>
      <td>12.40</td>
      <td>108.833091</td>
      <td>192.00000</td>
    </tr>
    <tr>
      <th>1993</th>
      <td>11.4</td>
      <td>6.00</td>
      <td>108.833091</td>
      <td>220.78348</td>
    </tr>
    <tr>
      <th>1994</th>
      <td>14.2</td>
      <td>8.70</td>
      <td>108.833091</td>
      <td>220.78348</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Display yearly trend graph (year vs. value) in pairs: (a) so2 and no2 (b) rspm and spm. 
# So, you will display TWO graphs altogether.

plt.subplot(2,2,1)
plt.plot(AndhraPradesh_records.index,AndhraPradesh_records.no2, linestyle = '-.',marker = 's', markerfacecolor = 'blue', color ='black', label ='no2')
plt.plot(AndhraPradesh_records.index,AndhraPradesh_records.so2,linestyle = '-', marker = 'o', markerfacecolor = 'red', color ='yellow', label = 'so2')
plt.legend(loc='upper left')
plt.title('year vs value')
plt.xlabel('year')
plt.ylabel('value')
plt.xticks(rotation = 30)
plt.subplot(2,2,2)
plt.plot(AndhraPradesh_records.index,AndhraPradesh_records.rspm, linestyle = '-',marker = 'o', markerfacecolor = 'blue', color ='purple', label ='rspm')
plt.plot(AndhraPradesh_records.index,AndhraPradesh_records.spm,linestyle = '-', marker = 'o', markerfacecolor = 'green', color ='black', label = 'spm')
plt.legend(loc='upper left')
plt.title('year vs value')
plt.xlabel('year')
plt.ylabel('value')
plt.xticks(rotation = 30)
plt.show()

```


    
![png](output_45_0.png)
    


Do you find anythumg alarming? Explain what you can conclude from this Exploratory Data Analysis for the State of Andhra Pradesh. Enter your answer here .....

Over the years, the SO2 which is toxic gas and suspended particular matter (spm) have been decreasing. However, the NO2 and rspm are increasing. It looks like Andhra Pradesh has been increasing their industry. The numers show there are more coal, gasoline, and oil burning. For the last 10 years, this state shows to have more factories, cars, and people. The state is getting more crowded and industrialized, but they did not provide the control or solution on the air polution. With the increasing of no2 and rspm, this will cost the air polution to the people who live there.
